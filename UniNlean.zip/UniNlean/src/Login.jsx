import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

function Login() {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = () => {
    const validUser = "testuser";
    const validPass = "12345";

    if (username === validUser && password === validPass) {
      alert("✅ Login Successful!");
      navigate("/dashboard"); // redirect to dashboard
    } else {
      alert("❌ Invalid Username or Password");
    }
  };

  return (
    <main className="mx-auto flex min-h-screen w-full items-center justify-center bg-gray-900 text-white">
      <section className="flex w-[30rem] flex-col space-y-10">
        <div className="text-center text-4xl font-medium">Welcome Nlean</div>

        <input
          type="text"
          placeholder="Email or Username"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
          className="border-b-2 bg-transparent text-lg focus:border-indigo-500"
        />

        <input
          type="password"
          placeholder="Password"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          className="border-b-2 bg-transparent text-lg focus:border-indigo-500"
        />

        <button
          onClick={handleLogin}
          className="bg-indigo-600 py-2 font-bold hover:bg-indigo-400"
        >
          LOG IN
        </button>
      </section>
    </main>
  );
}

export default Login;
