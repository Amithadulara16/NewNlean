import React from "react";
import { useNavigate } from "react-router-dom";

function Logout() {
  const navigate = useNavigate();

  const handleLogout = () => {
    // Clear any saved tokens or session
    localStorage.removeItem("token"); 
    sessionStorage.clear();

    // Redirect to login page
    navigate("/login");
  };

  const handleCancel = () => {
    navigate("/dashboard"); // redirect back to dashboard/home
  };

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100">
      <div className="bg-white p-8 rounded-2xl shadow-lg max-w-sm w-full text-center">
        <h1 className="text-2xl font-bold text-gray-800 mb-4">Logout</h1>
        <p className="text-gray-600 mb-6">
          Are you sure you want to logout from your account?
        </p>

        <div className="flex space-x-4 justify-center">
          <button
            onClick={handleLogout}
            className="px-5 py-2 bg-red-500 text-white rounded-lg shadow hover:bg-red-600 transition"
          >
            Logout
          </button>
          <button
            onClick={handleCancel}
            className="px-5 py-2 bg-gray-300 text-gray-800 rounded-lg shadow hover:bg-gray-400 transition"
          >
            Cancel
          </button>
        </div>
      </div>
    </div>
  );
}

export default Logout;
