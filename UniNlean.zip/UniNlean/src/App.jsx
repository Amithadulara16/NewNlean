import { useState } from 'react'
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Login from './Login'
import Dsbo from './Dsbo'
import Logout from "./Logout";


function App() {
  const [count, setCount] = useState(0)

  return (
    <>
    <Router>
      <Routes>
        <Route path="/" element={<Login />} />
        <Route path="/dashboard" element={<Dsbo />} />
        <Route path="*" element={<Login />} /> {/* fallback */}
      </Routes>
    </Router>
    </>
  )
}

export default App
