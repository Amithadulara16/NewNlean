import React from "react";
import { Link } from "react-router-dom";

// Example course data
const courses = [
  {
    title: "SE202.3-Introduction to Software Engineering",
    semester: "Year 2 - Semester 2",
    color: "bg-indigo-500",
    progress: 85,
  },
  {
    title: "CS202.3-Systems Fundamentals",
    semester: "Year 2 - Semester 2",
    color: "bg-gray-400",
    progress: 65,
  },
  {
    title: "SE206.3-Human Computer Interaction",
    semester: "Year 2 - Semester 2",
    color: "bg-pink-400",
    progress: 47,
  },
  {
    title: "CS203.3-Algorithms and Complexity",
    semester: "Year 2 - Semester 2",
    color: "bg-green-500",
    progress: 50,
  },
];

function Dsbo() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <header className="flex items-center justify-between bg-indigo-600 shadow px-6 py-4">
        <div className="flex items-center space-x-2">
          <span className="text-2xl font-bold text-white">NLEARN</span>
          <span className="text-xs text-gray-200">MY NEW NLEAN</span>
        </div>
        <nav className="flex space-x-6 text-white font-medium">
          <Link to="/dashboard" className="hover:text-gray-200">Home</Link>
          <a href="#" className="hover:text-gray-200">Events</a>
          <a href="#" className="hover:text-gray-200">My Courses</a>
          {/* ✅ Link to Logout page */}
          <Link to="/logout" className="hover:text-gray-200">Logout</Link>
        </nav>
      </header>

      {/* Main content */}
      <main className="p-6">
        {/* Recently Accessed */}
        <section>
          <h2 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">
            Recently accessed courses
          </h2>
          <div className="flex space-x-4 overflow-x-auto pb-4">
            {courses.map((course, idx) => (
              <div
                key={idx}
                className="bg-white rounded-lg shadow-lg w-64 flex-shrink-0"
              >
                <div className={`${course.color} h-24 rounded-t-lg`}></div>
                <div className="p-4">
                  <h3 className="text-sm font-medium text-gray-800">{course.semester}</h3>
                  <p className="text-gray-600 text-sm">{course.title}</p>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Course Overview */}
        <section className="mt-8">
          <h2 className="text-lg font-semibold text-gray-800 border-b pb-2 mb-4">
            Course overview
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {courses.map((course, idx) => (
              <div
                key={idx}
                className="bg-white rounded-lg shadow-lg p-4 flex flex-col"
              >
                <div className={`${course.color} h-24 rounded-md mb-4`}></div>
                <h3 className="font-medium text-gray-800">{course.semester}</h3>
                <p className="text-sm text-gray-600">{course.title}</p>
                <div className="mt-3">
                  <div className="flex justify-between text-sm text-gray-600 mb-1">
                    <span>{course.progress}% complete</span>
                  </div>
                  <div className="w-full bg-gray-200 h-2 rounded">
                    <div
                      className="bg-blue-500 h-2 rounded"
                      style={{ width: `${course.progress}%` }}
                    ></div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>
      </main>
    </div>
  );
}

export default Dsbo;
